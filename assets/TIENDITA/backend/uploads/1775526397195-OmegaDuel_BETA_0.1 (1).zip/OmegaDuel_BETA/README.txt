Cómo usar:
1) Abre run.bat (doble clic)
2) Agrega jugadores o equipos
3) Genera llaves
4) Click en cada match para elegir ganador
5) Exporta PNG para compartir

Carpetas:
- decks/     -> imágenes de decks
- logos/     -> logos de torneo/equipos
- exports/   -> imágenes PNG exportadas
- torneos/   -> archivos .tmd guardados