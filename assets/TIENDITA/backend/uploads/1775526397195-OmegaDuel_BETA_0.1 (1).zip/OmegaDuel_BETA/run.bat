@echo off
cd /d "%~dp0"
java -jar OmegaDuel.jar
pause
